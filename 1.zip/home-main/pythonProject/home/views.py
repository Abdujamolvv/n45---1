from django.http import HttpResponse

def get_info(request):
    return HttpResponse('Hello world')
